import React, { useState, useCallback } from "react";
import { Handle, Position, useReactFlow } from "@xyflow/react";
import { RiDeleteBinLine } from "react-icons/ri";

// Styles for the handles
const handleStyle = { left: 10 };

// Interface for the TextUpdaterNode component props
interface TextUpdaterNodeProps {
  data: {
    id: string;
    text: string;
    onChange: (value: string) => void;
  };
  isConnectable: boolean;
}

// The component for the dynamic condition node
function TextUpdaterNode({ data, isConnectable }: TextUpdaterNodeProps) {
  // State to hold multiple condition rows
  const [conditions, setConditions] = useState([
    { condition: "Fever", operator: ">", value: "101°F" },
  ]);

  const { setNodes } = useReactFlow();

  // Function to handle text input change
  const onChange = useCallback(
    (evt: React.ChangeEvent<HTMLInputElement>) => {
      data.onChange(evt.target.value);
    },
    [data]
  );

  // Function to delete the current node
  const handleDelete = () => {
    setNodes((nodes) => nodes.filter((node) => node.id !== data.id));
  };

  // Function to handle adding a new condition row
  const addConditionRow = () => {
    setConditions([...conditions, { condition: "", operator: "", value: "" }]);
  };

  // Function to handle deleting a specific condition row
  const deleteConditionRow = (index: number) => {
    setConditions((prev) => prev.filter((_, i) => i !== index));
  };

  // Function to update a specific condition row
  const updateConditionRow = (index: number, field: string, value: string) => {
    setConditions((prev) =>
      prev.map((row, i) => (i === index ? { ...row, [field]: value } : row))
    );
  };

  return (
    <div
      className="text-updater-node"
      style={{
        padding: 10,
        border: "1px solid #777",
        backgroundColor: "white",
        borderRadius: 4,
      }}
    >
      {/* Delete Node Button */}
      {/* <button type="button" onClick={handleDelete}>
        Delete Node
      </button> */}

      {/* Top Handle for Inputs */}
      <Handle
        type="target"
        position={Position.Top}
        isConnectable={isConnectable}
      />

      {/* Text Input */}
      <div>
        <label htmlFor="text">Text:</label>
        <input
          id="text"
          name="text"
          onChange={onChange}
          className="nodrag"
          value={data.text}
        />
      </div>

      {/* Dynamic Condition Rows */}
      <div>
        {conditions.map((condition, index) => (
          <div
            key={index}
            style={{
              display: "flex",
              marginBottom: "5px",
              justifyContent: "space-between",
              padding: 15,
              borderRadius: 10,
              backgroundColor: "#f0f0f0",
            }}
          >
            <input
              type="text"
              placeholder="Condition"
              value={condition.condition}
              onChange={(e) =>
                updateConditionRow(index, "condition", e.target.value)
              }
            />
            <label htmlFor="">s</label>
            <select
              title="Operator"
              value={condition.operator}
              name="operator"
              onChange={(e) =>
                updateConditionRow(index, "operator", e.target.value)
              }
            >
              <option value=">">"g"</option>
              <option value="<">l</option>
              <option value="=">=</option>
            </select>
            <input
              type="text"
              placeholder="Value"
              value={condition.value}
              onChange={(e) =>
                updateConditionRow(index, "value", e.target.value)
              }
            />
            {/* Delete Row Button */}
            <button
              title="Delete"
              style={{ backgroundColor: "transparent" }}
              type="button"
              onClick={() => deleteConditionRow(index)}
            >
              <RiDeleteBinLine color="black" size={30} />
            </button>
          </div>
        ))}
      </div>

      {/* Add New Row Button */}
      <button
        type="button"
        style={{
          backgroundColor: "#E9F2FF",
        }}
        onClick={addConditionRow}
      >
        <span style={{ color: "blue", padding: 0 }}>Save </span>
      </button>

      {/* Bottom Handles for Outputs */}
      <Handle
        type="source"
        position={Position.Bottom}
        id="a"
        style={handleStyle}
        isConnectable={isConnectable}
      />
      <Handle
        type="source"
        position={Position.Bottom}
        id="b"
        isConnectable={isConnectable}
      />
    </div>
  );
}

export default TextUpdaterNode;
