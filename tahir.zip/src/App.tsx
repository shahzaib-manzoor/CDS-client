import { useState } from 'react'
import './App.css'    
import MindMap from './components/Mindmap'


function App() {
 

  return (
    <>
     <div style={{ height: 1000,width:3000 }}>
   <MindMap/>
   </div>
    </>
  )
}

export default App
